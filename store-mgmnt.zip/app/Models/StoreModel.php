<?php

namespace App\Models;

use CodeIgniter\Model;

class StoreModel extends Model
{

    protected $table            = 'stores';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = false;
    protected $insertID         = 0;
    protected $useSoftDeletes   = true;
    protected $protectFields    = false;

    protected $useTimestamps = true;



}
