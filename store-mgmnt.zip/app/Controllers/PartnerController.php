<?php

namespace App\Controllers;


use App\Helpers\AuthenticationHelper;

class PartnerController extends BaseController
{
    private $partnerModel;

    public function __construct()
    {
        $this->partnerModel = model('partnerModel');
    }

    public function getPartners()
    {
        if ( AuthenticationHelper::getRole($this->request) == null)
        {
            return $this->failUnauthorized();
        }

        $data = $this->partnerModel->select('phone_number, full_name, deleted_at')->withDeleted()->findAll();

        foreach ($data as &$item)
        {
            $item['is_active'] = !isset($item['deleted_at']);
            unset($item['deleted_at']);
        }

        return $this->responseSuccess($data);
    }

    public function createPartner()
    {
        if ( AuthenticationHelper::getRole($this->request) == null)
        {
            return $this->failUnauthorized();
        }

        $data = $this->readParamsAndValidate([
        'phone_number' => 'required|min_length[12]|is_unique[users.phone_number]',
        'full_name' => 'required|min_length[2]',
        ]);

        if( ! isset($data) ) { return $this->fail($this->validator->getErrors()); }


        $this->partnerModel->insert($data);
        return $this->responseSuccess(null, "Partner created successfully");

    }

    public function updatePartner()
    {
        $data = $this->readParamsAndValidate([
            'user_id' => 'required|min_length[2]',
            'full_name' => 'required|min_length[2]',
        ]);

        if( ! isset($data) ) {
            return $this->fail($this->validator->getErrors());
        }

        //TODO: Check if this is really a partner


        $this->partnerModel->update($data['user_id'], $data);
        return $this->responseSuccess(null, "Partner updated successfully");
    }

    public function blockPartner()
    {
        $data = $this->readParamsAndValidate([
            'user_id' => 'required|min_length[2]',
        ]);

        if( ! isset($data) ) {
            return $this->fail($this->validator->getErrors());
        }

        $this->partnerModel->delete($data['phone_number']);
        return $this->responseSuccess(null, "Partner ${data['phone_number']} blocked successfully");

    }




}
