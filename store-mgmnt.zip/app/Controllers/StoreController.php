<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Helpers\AuthenticationHelper;

class StoreController extends BaseController
{
    private $storeModel;

    public function __construct()
    {
        $this->storeModel = model('storeModel');
    }

    public function getStores()
    {


        $data = $this->storeModel->select('store_id, full_name, deleted_at')->withDeleted()->findAll();

        foreach ($data as &$item)
        {
            $item['is_active'] = !isset($item['deleted_at']);
            unset($item['deleted_at']);
        }

        return $this->responseSuccess($data);
    }

    public function createStore()
    {

        $data = $this->readParamsAndValidate([
            'full_name' => 'required|min_length[2]',
        ]);

        if( ! isset($data) ) { return $this->fail($this->validator->getErrors()); }


        $data["owner"] = AuthenticationHelper::getConnectedUserPhoneNumber($this->request);


        $this->storeModel->insert($data);
        return $this->responseSuccess(null, "Store created successfully");

    }

    public function updateStore()
    {
        $data = $this->readParamsAndValidate([
            'store_id' => 'required', //TODO: Check it exist in the database
            'full_name' => 'required|min_length[2]',
        ]);

        if( ! isset($data) ) {
            return $this->fail($this->validator->getErrors());
        }

        $this->storeModel->update($data['store_id'], $data);
        return $this->responseSuccess(null, "Store ${data['store_id']} updated successfully");
    }
}
