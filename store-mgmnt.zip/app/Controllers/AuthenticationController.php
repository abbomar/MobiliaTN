<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class AuthenticationController extends BaseController
{
    public function me()
    {


    }
}
