<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class ManagerController extends BaseController
{
    public function index()
    {
        //
    }
}
